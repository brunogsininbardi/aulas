package com.ems.bdsqlite;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActivityDelete extends AppCompatActivity {

    ListView listViewNA;
    ArrayList<Item> itens = new ArrayList<>();
    ArrayAdapter<Item> adaptador;


    SQLiteDatabase db;




    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("Fechar", null);
        //builder.setIcon(R.drawable.dizzi);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_delete);



        listViewNA = findViewById(R.id.listViewStorage);

        db = openOrCreateDatabase("db_list", Context.MODE_PRIVATE, null);

        db.execSQL("CREATE TABLE IF NOT EXISTS item(name VARCHAR, price FLOAT, description VARCHAR);");


        // Carrega os registros em ordem alfabética no ArrayList para anexar ao adaptador
        itens.clear();
        Cursor c = db.rawQuery("SELECT name,description,price FROM item ORDER BY name ASC", null);
        while (c.moveToNext()) {
            itens.add(new Item(
                    c.getString(0),
                    c.getString(1),
                    c.getFloat(2)));
        }
        // Configura o adaptador
        adaptador = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                itens);

        // Anexa o adaptador à ListView
        listViewNA.setAdapter(adaptador);e

        listViewNA.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Item i = (Item) listViewNA.getItemAtPosition(position);
                String[] args = new String[]{i.getName().toString()};

                db.delete("item", "name=?", args);

            }
        });



    }

}