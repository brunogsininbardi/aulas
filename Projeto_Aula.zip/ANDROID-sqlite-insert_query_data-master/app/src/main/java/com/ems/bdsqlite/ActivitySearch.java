package com.ems.bdsqlite;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActivitySearch extends AppCompatActivity {

    ListView listViewNA;
    TextView new_name, new_price, new_description,editTextSearch;
    Button btSearch;
    ArrayList<Item> itens = new ArrayList<>();
    ArrayList<Item> itens_search = new ArrayList<>();
    SQLiteDatabase db;




    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("Fechar", null);
        //builder.setIcon(R.drawable.dizzi);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {
        new_name.setText("");
        new_price.setText("");
        new_description.setText("");
        new_name.requestFocus();

        // fecha o teclado virtual
        ((InputMethodManager) ActivitySearch.this.getSystemService(
                Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(
                getCurrentFocus().getWindowToken(), 0);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        new_name = findViewById(R.id.editTextNome2);
        new_price = findViewById(R.id.editTextPrice2);
        new_description = findViewById(R.id.editTextDesc2);
        editTextSearch = findViewById(R.id.editTextSearch);
        btSearch = findViewById(R.id.btSearch);
        db = openOrCreateDatabase("db_list", Context.MODE_PRIVATE, null);

        db.execSQL("CREATE TABLE IF NOT EXISTS item(name VARCHAR, price FLOAT, description VARCHAR);");


        btSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                itens.clear();
                Cursor c = db.rawQuery("SELECT name,description,price FROM item ORDER BY name ASC", null);
                while (c.moveToNext()) {
                    itens.add(new Item(
                            c.getString(0),
                            c.getString(1),
                            c.getFloat(2)));
                }

                for(int i=0;i<itens.size();i++){
                    if(itens.get(i).getName().toUpperCase().equals(editTextSearch.getText().toString().toUpperCase())){
                        new_name.setText(itens.get(i).getName());
                        new_price.setText(itens.get(i).getPrice().toString());
                        new_description.setText(itens.get(i).getDesc());
                        break;
                    }
                }

            }
        });




    }







}