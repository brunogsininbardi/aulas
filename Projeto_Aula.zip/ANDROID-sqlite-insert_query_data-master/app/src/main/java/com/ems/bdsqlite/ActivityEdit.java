package com.ems.bdsqlite;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActivityEdit extends AppCompatActivity {

    ListView storage;
    TextView new_name, new_price, new_description;
    Button btEdit;

    ArrayList<Item> itens = new ArrayList<>();

    ArrayAdapter<Item> adapter;

    SQLiteDatabase db;


    public void loadData() {

        itens.clear();
        Cursor c = db.rawQuery("SELECT * FROM item ORDER BY name ASC", null);
        while (c.moveToNext()) {
            itens.add(new Item(c.getString(0), c.getString(1), c.getFloat(2)));
        }

    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("Fechar", null);
        //builder.setIcon(R.drawable.dizzi);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {
        new_name.setText("");
        new_price.setText("");
        new_description.setText("");
        new_name.requestFocus();

        // fecha o teclado virtual
        ((InputMethodManager) ActivityEdit.this.getSystemService(
                Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(
                getCurrentFocus().getWindowToken(), 0);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit);

        new_name = findViewById(R.id.editTextNome);
        new_price = findViewById(R.id.editTextPrice);
        new_description = findViewById(R.id.editTextDesc);
        btEdit = findViewById(R.id.btEdit);

        db = openOrCreateDatabase("db_list", Context.MODE_PRIVATE, null);

        db.execSQL("CREATE TABLE IF NOT EXISTS item(name VARCHAR, price FLOAT, description VARCHAR);");

        loadData();

        btEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                StringBuilder sb = new StringBuilder(new_name.getText().toString());
                ContentValues values = new ContentValues();
                values.put("name", sb.toString());
                values.put("price", new_price.getText().toString());
                values.put("description", new_description.getText().toString());

                String[] args = new String[]{new_name.getText().toString()};

                if((sb.toString()==null)
                        || (new_price.getText().toString()==null)
                        || new_description.getText().toString() ==null ){
                    showMessage("Preencha todos os campos", "Preencha todos os campos!");
                }

                else {
                    db.update("item", values, "name=?", args);
                }
                loadData();
               // adapter.notifyDataSetChanged();
                showMessage("Successo", "Item Atualizado!");
                Intent it = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(it);
                finish();

            }

        });
    }

}




