package com.ems.bdsqlite;

import java.io.Serializable;

public class Item implements Serializable {
    private String name;
    private String description;
    private Float price;

    public Item(String name, String description, Float price) {
        this.setName(name);
        this.setDesc(description);
        this.setPrice(price);

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return description;
    }

    public void setDesc(String desc) {
        this.description = desc;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return name;
    }

    public String getDados() {
        return  "Nome: " + name + "\n" +
                "Descrição: " + description + "\n" +
                "Preço: " + price + "\n" ;
    }
}
