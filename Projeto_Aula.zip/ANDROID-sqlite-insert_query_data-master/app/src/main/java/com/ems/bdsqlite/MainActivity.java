package com.ems.bdsqlite;

// Reproduzir este exemplo: https://www.androidpro.com.br/blog/armazenamento-de-dados/sqlite/

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements Serializable {
    // Variáveis para os objetos da View

    Button btList, btInsert, btDelete, btUpdate, btSearch;

    // Cria um ArrayList para receber os dados dos objetos
    ArrayList<Item> itens = new ArrayList<>();

    // Cria um ArrayAdapter para anexar à ListView
    ArrayAdapter<Item> adapter;

    // Cria uma variável para trabalhar com o SQLite
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btList = findViewById(R.id.btList);
        btInsert = findViewById(R.id.btInsert);
        btDelete = findViewById(R.id.btDelete);
        btUpdate = findViewById(R.id.btUpdate);
        btSearch = findViewById(R.id.btSearch);


        db = openOrCreateDatabase("db_list", Context.MODE_PRIVATE, null);

        db.execSQL("CREATE TABLE IF NOT EXISTS item(name VARCHAR, price FLOAT, description VARCHAR);");

        loadData();

        // Cria o Adapter para popular a ListView
        adapter = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                itens);


        btUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), ActivityEdit.class);
                startActivity(intent);

            }
        });



        btList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), ActivityList.class);
                startActivity(intent);

            }
        });

        btSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), ActivitySearch.class);
                startActivity(intent);

            }
        });

        btInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), ActivityInsert.class);
                startActivity(intent);

            }
        });


        btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), ActivityDelete.class);
                startActivity(intent);

            }
        });

    }

    public void loadData() {
        // Carrega os dados existentes no banco de dados
        itens.clear();
        Cursor c = db.rawQuery("SELECT * FROM item ORDER BY name ASC", null);
        while (c.moveToNext()) {
            itens.add(new Item(c.getString(0), c.getString(1), c.getFloat(2)));
        }
    }

    /**
     * Caixa de Mensagem
     *
     * @param title   título da caixa de mensagem
     * @param message mensagem que será mostrada na tela
     */
    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("Fechar", null);
        //builder.setIcon(R.drawable.dizzi);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {

        // fecha o teclado virtual
        ((InputMethodManager) MainActivity.this.getSystemService(
                Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(
                getCurrentFocus().getWindowToken(), 0);
    }



}
